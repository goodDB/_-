// pages/myData/myData.js
Page({
  data: {
    url:['../image/my_1.jpg','../image/my_2.jpg','../image/my_3.jpg','../image/my_4.jpg']
  }
})